﻿USE [FlexiForbesv2];
GO

-- CAT: LO QUE SE HIZO FUE aplicar el ALTER de dbo.ff_CalculaExcedentes.
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER OFF;
GO



/*
NOMBRE: ff_CalculaExcedentes
FECHA DE CREACIÓN : 30/08/2006
PROGRAMADOR: Cristina Delgadillo Hdez
FUNCIÓN: Store Procedure que calcula e inserta ó actualiza los excedentes 
de los empleados de Dupont. 
FECHAUMOD:

DROP procedure ff_CalculaExcedentes
dbo.ff_CalculaExcedentes 22439
NO ESTA EN USO

*/


ALTER PROCEDURE [dbo].[ff_CalculaExcedentes] (@idempleado int)
AS

            
  BEGIN 
      
    
	DECLARE @vales money
        DECLARE @fondo money
        DECLARE @emsalariobase money
        DECLARE @excedentes money
        DECLARE @tope_vales money
        DECLARE @tope_fondo money
        DECLARE @Sqlactualiza nvarchar (100)
        DECLARE @Sqlinserta nvarchar (100)
        DECLARE @Idcompensacion nvarchar (100)
        DECLARE @Busqueda nvarchar (100)
        DECLARE @r1 money
        DECLARE @r2 money
        DECLARE @emvalesp money
        DECLARE @emfondoahorrop money
        DECLARE @idem int
        Declare @Existe AS int	
	Declare @maxCom AS INT
        SET @maxCom = 0

--      SELECT  @Sqlactualiza = ''
--      SELECT  @Sqlinserta = ''
--      SELECT  @Idcompensacion = ''
        SET @tope_vales = 1479.568
        SET @tope_fondo = 1923.4384
	SET @Existe = 0

       /* SET @emsalariobase = (SELECT  emsalariobase 
	FROM ff_empleado 
	WHERE emidempresa IN (66,67)        
	AND emidtitular = 1
        AND emidestatus = 1
        AND id = @idempleado)*/
        SELECT @emsalariobase=emSalariobase, @emvalesp=emvalesp,@emfondoahorrop =emfondoahorrop 
        FROM ff_empleado 
	WHERE emidempresa IN (66,67)        
	AND emidtitular = 1
        AND emidestatus = 1
        AND id = @idempleado


--        AND emsalariobase > 14800)

/*        SET @emvalesp = (SELECT emvalesp 
        FROM ff_empleado
        WHERE emidempresa IN (66,67)        
	AND emidtitular = 1
        AND emidestatus = 1
        AND id = @idempleado)
--        AND emsalariobase > 14800)

        SET @emfondoahorrop = (SELECT emfondoahorrop 
        FROM ff_empleado
        WHERE emidempresa IN (66,67)        
	AND emidtitular = 1
        AND emidestatus = 1
        AND id = @idempleado )
--        AND emsalariobase > 14800)
*/
        print CAST(@emsalariobase AS varchar)

        SET @excedentes = 0

        IF (@emsalariobase) > 0
        BEGIN 
        --SELECT  emsalariobase = @emsalariobase FROM ff_empleado WHERE id = @idempleado AND emidtitular = 1
        SET @r1= (@emvalesp * @emsalariobase)- @tope_vales
        IF  (@r1 > 0) 
          BEGIN   
           SET @vales = @r1 -- (@emsalariobase * .1) - @tope_vales
           SET @r2 = (@emfondoahorrop * @emsalariobase)  - @tope_fondo
            IF (@r2 > 0)
               BEGIN  
                  SET @fondo = @r2
                  SET @excedentes = (@vales + @fondo)* 12
		  SET @Existe =(SELECT count(*) FROM ff_compensacionempleado WHERE  ceidempleado = @idempleado)		
                  IF (@Existe > 0)
                     BEGIN 
			UPDATE  ff_compensacionempleado SET cetotalcreditos = @excedentes WHERE ceidempleado = @idempleado
                         --SELECT @Sqlactualiza = 'UPDATE  ff_compensacionempleado SET cetotalcreditos = @excedentes WHERE idempleado = @idempleado'
                        --EXECUTE(@Sqlactualiza)
                      END
                    ELSE 
                     BEGIN 
			
			-- CAT: LO QUE SE HIZO FUE reemplazar MAX + 1 por una SEQUENCE compartida.
			-- CAT: Esto evita IDs repetidos cuando dos procesos insertan al mismo tiempo.
			SET @maxCom = NEXT VALUE FOR dbo.Seq_ff_CompensacionEmpleado;
			
			INSERT ff_compensacionempleado (ceidcompensacionempleado, ceidcompensacion, ceidempleado, cetotalcreditos)
                        VALUES (@maxCom,18,@idempleado,@excedentes)
			
			/*	
                        SELECT @Idcompensacion = SELECT Max (ceidcompensacionempleado) + 1 FROM ff_compensacionempleado
                        SELECT @Sqlinserta = INSERT ff_compensacionempleado (ceidcompensacionempleado, ceidcompensacion, ceidempleado, cetotalcreditos)
                                              VALUES (EXEC(@Idcompensacion),18,@idempleado,@excedentes)
                        EXEC(@Sqlinserta)         
			*/
                      END   
			
               END
            ELSE
               BEGIN 
                  SET @fondo = 0
               END
           END
        ELSE
          BEGIN 
           --SET @vales = 0
           UPDATE  ff_compensacionempleado SET cetotalcreditos = 0 WHERE ceidempleado = @idempleado
          END
      END
END


GO

PRINT 'OK: dbo.ff_CalculaExcedentes';
GO