﻿USE [FlexiForbesv2];
GO
SET NOCOUNT ON;

IF CONVERT(NVARCHAR(128), SERVERPROPERTY('ServerName')) NOT LIKE N'%LOCALDB%'
    THROW 51320, 'Esta prueba solo se permite en LocalDB.', 1;

SELECT
    COUNT(*) AS totalFilas,
    COUNT(DISTINCT Id) AS idsDistintos,
    SUM(CASE WHEN Sesion = 'A' THEN 1 ELSE 0 END) AS sesionA,
    SUM(CASE WHEN Sesion = 'B' THEN 1 ELSE 0 END) AS sesionB,
    MIN(Id) AS idMinimo,
    MAX(Id) AS idMaximo
FROM dbo.CAT_PruebaSequence_10292;

IF (SELECT COUNT(*) FROM dbo.CAT_PruebaSequence_10292) <> 1000
    THROW 51321, 'Se esperaban 1000 filas.', 1;

IF (SELECT COUNT(DISTINCT Id) FROM dbo.CAT_PruebaSequence_10292) <> 1000
    THROW 51322, 'Se detectaron IDs repetidos.', 1;

DROP TABLE dbo.CAT_PruebaSequence_10292;
PRINT 'PRUEBA_CONCURRENCIA_OK: 1000 filas y 1000 IDs distintos.';
GO