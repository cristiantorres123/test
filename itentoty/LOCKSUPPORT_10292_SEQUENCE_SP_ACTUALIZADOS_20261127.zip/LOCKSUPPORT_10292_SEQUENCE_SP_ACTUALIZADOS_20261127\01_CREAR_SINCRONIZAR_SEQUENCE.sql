﻿USE [FlexiForbesv2];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;

-- CAT: LO QUE SE HIZO FUE crear o sincronizar una SEQUENCE con MAX actual + 1.
-- CAT: El valor no queda fijo; se calcula de nuevo en cada ambiente.
BEGIN TRY
    BEGIN TRANSACTION;

    IF OBJECT_ID(N'dbo.ff_CompensacionEmpleado', N'U') IS NULL
        THROW 51100, 'No existe dbo.ff_CompensacionEmpleado.', 1;

    DECLARE @Maximo BIGINT;
    DECLARE @Siguiente BIGINT;
    DECLARE @Sql NVARCHAR(MAX);

    SELECT @Maximo = ISNULL(MAX(CONVERT(BIGINT, CEIdCompensacionEmpleado)), 0)
    FROM dbo.ff_CompensacionEmpleado WITH (TABLOCKX, HOLDLOCK);

    SET @Siguiente = CASE WHEN @Maximo < 1 THEN 1 ELSE @Maximo + 1 END;

    IF @Siguiente > 2147483647
        THROW 51101, 'No hay espacio disponible en INT para el siguiente identificador.', 1;

    IF OBJECT_ID(N'dbo.Seq_ff_CompensacionEmpleado', N'SO') IS NULL
    BEGIN
        SET @Sql = N'CREATE SEQUENCE dbo.Seq_ff_CompensacionEmpleado
                       AS INT
                       START WITH ' + CONVERT(NVARCHAR(20), @Siguiente) + N'
                       INCREMENT BY 1
                       MINVALUE 1
                       MAXVALUE 2147483647
                       NO CYCLE
                       CACHE 50;';
        EXEC sys.sp_executesql @Sql;
        PRINT 'OK: sequence creada desde ' + CONVERT(VARCHAR(20), @Siguiente);
    END
    ELSE
    BEGIN
        IF EXISTS
        (
            SELECT 1
            FROM sys.sequences
            WHERE object_id = OBJECT_ID(N'dbo.Seq_ff_CompensacionEmpleado')
              AND
              (
                  TYPE_NAME(user_type_id) <> N'int'
                  OR CONVERT(BIGINT, increment) <> 1
                  OR is_cycling = 1
                  OR CONVERT(BIGINT, minimum_value) <> 1
                  OR CONVERT(BIGINT, maximum_value) <> 2147483647
              )
        )
            THROW 51102, 'La sequence existe pero su configuracion no coincide.', 1;

        DECLARE @Actual BIGINT;
        SELECT @Actual = CONVERT(BIGINT, COALESCE(current_value, start_value))
        FROM sys.sequences
        WHERE object_id = OBJECT_ID(N'dbo.Seq_ff_CompensacionEmpleado');

        IF @Actual <= @Maximo
        BEGIN
            -- CAT: Solo se adelanta la SEQUENCE; nunca se reinicia hacia atras.
            SET @Sql = N'ALTER SEQUENCE dbo.Seq_ff_CompensacionEmpleado RESTART WITH ' +
                       CONVERT(NVARCHAR(20), @Siguiente) + N';';
            EXEC sys.sp_executesql @Sql;
            PRINT 'OK: sequence adelantada a ' + CONVERT(VARCHAR(20), @Siguiente);
        END
        ELSE
            PRINT 'OK: sequence ya estaba por delante del maximo de la tabla.';
    END;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO