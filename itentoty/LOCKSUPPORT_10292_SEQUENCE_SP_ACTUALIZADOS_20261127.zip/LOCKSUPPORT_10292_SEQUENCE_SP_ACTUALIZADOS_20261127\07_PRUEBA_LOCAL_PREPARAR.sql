﻿USE [FlexiForbesv2];
GO
SET NOCOUNT ON;

-- CAT: Prueba permitida solo en LocalDB. Consume valores de la SEQUENCE.
IF CONVERT(NVARCHAR(128), SERVERPROPERTY('ServerName')) NOT LIKE N'%LOCALDB%'
    THROW 51300, 'Esta prueba solo se permite en LocalDB.', 1;

IF OBJECT_ID(N'dbo.Seq_ff_CompensacionEmpleado', N'SO') IS NULL
    THROW 51301, 'Primero instala la SEQUENCE.', 1;

IF OBJECT_ID(N'dbo.CAT_PruebaSequence_10292', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.CAT_PruebaSequence_10292
    (
        Id INT NOT NULL PRIMARY KEY,
        Sesion CHAR(1) NOT NULL,
        SPID INT NOT NULL,
        Fecha DATETIME2(3) NOT NULL
    );
END
ELSE
    TRUNCATE TABLE dbo.CAT_PruebaSequence_10292;

PRINT 'OK: tabla de prueba preparada.';
GO