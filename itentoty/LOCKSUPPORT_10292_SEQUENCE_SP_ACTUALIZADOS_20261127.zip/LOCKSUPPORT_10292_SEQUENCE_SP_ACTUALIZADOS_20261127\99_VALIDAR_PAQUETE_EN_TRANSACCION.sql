﻿:ON ERROR EXIT
USE [FlexiForbesv2];
GO

-- CAT: Valida sintaxis y resultado sin dejar los ALTER aplicados.
-- CAT: Ejecutar con sqlcmd desde la carpeta raiz de este paquete.
BEGIN TRANSACTION;
GO
:r .\00_PREVALIDAR.sql
:r .\01_CREAR_SINCRONIZAR_SEQUENCE.sql
:r .\02_ALTER_ff_VerificaExcedentes.sql
:r .\03_ALTER_FF_CALCULARCOMPENSACION.sql
:r .\04_ALTER_ff_guardarCompensacionBonoAuto.sql
:r .\05_ALTER_ff_CalculaExcedentes.sql
:r .\06_VALIDAR_INSTALACION.sql
ROLLBACK TRANSACTION;
GO
PRINT 'PRUEBA_TRANSACCIONAL_OK: los cambios fueron revertidos.';
GO