﻿LOCKSUPPORT 10292 - CORRECCION DE IDs EN ff_CompensacionEmpleado

SERVIDOR USADO PARA ARMAR Y VALIDAR EL PAQUETE
- Servidor: (localdb)\MSSQLLocalDB
- Base: FlexiForbesv2
- Maximo observado al generar: 6586530
- El instalador NO fija 6586531; calcula MAX + 1 al ejecutarse.

CAMBIOS
- Se crea dbo.Seq_ff_CompensacionEmpleado.
- ff_VerificaExcedentes: 6 reemplazos.
- FF_CALCULARCOMPENSACION: 1 reemplazo.
- ff_guardarCompensacionBonoAuto: 1 reemplazo, dentro de la rama INSERT.
- ff_CalculaExcedentes: 1 reemplazo activo. Su encabezado dice NO ESTA EN USO.
- No hay cambio Java.

IMPORTANTE
- Los comentarios usan -- CAT: porque // no es comentario valido en SQL Server.
- Detener servicios, WCF, APIs y jobs que escriban en ff_CompensacionEmpleado.
- No mezclar temporalmente SP con MAX + 1 y SP con SEQUENCE.
- Los huecos de numeracion son normales en una SEQUENCE.
- ff_CalculaExcedentes conserva texto MAX + 1 dentro de un comentario legado; no se ejecuta.

ORDEN DE INSTALACION
En LocalDB se puede ejecutar todo con:
sqlcmd -S "(localdb)\MSSQLLocalDB" -E -d FlexiForbesv2 -b -i ".\12_INSTALAR_TODO_LOCALDB.sql"

O ejecutar uno por uno:
1. 00_PREVALIDAR.sql
2. 01_CREAR_SINCRONIZAR_SEQUENCE.sql
3. 02_ALTER_ff_VerificaExcedentes.sql
4. 03_ALTER_FF_CALCULARCOMPENSACION.sql
5. 04_ALTER_ff_guardarCompensacionBonoAuto.sql
6. 05_ALTER_ff_CalculaExcedentes.sql
7. 06_VALIDAR_INSTALACION.sql
8. Reactivar servicios y jobs.

RESULTADO ESPERADO
- PREVALIDACION_OK.
- VALIDACION_OK.
- La SEQUENCE queda por delante del MAX de la tabla.
- Los SP muestran 6, 1, 1 y 1 usos de NEXT VALUE FOR.
- No aparece error SQL 2601 ni 2627 en pruebas simultaneas.

PRUEBA RAPIDA EN LOCALDB
1. Ejecutar 07_PRUEBA_LOCAL_PREPARAR.sql.
2. Abrir dos ventanas de SSMS.
3. Ejecutar 08_PRUEBA_LOCAL_SESION_A.sql y 09_PRUEBA_LOCAL_SESION_B.sql casi juntas.
4. Ejecutar 10_PRUEBA_LOCAL_RESULTADO_LIMPIEZA.sql.
5. Resultado esperado: 1000 filas, 1000 IDs distintos y cero errores 2601/2627.

VALIDACION DEL ZIP SIN DEJAR CAMBIOS
Desde PowerShell, dentro de esta carpeta:
sqlcmd -S "(localdb)\MSSQLLocalDB" -E -d FlexiForbesv2 -b -i ".\99_VALIDAR_PAQUETE_EN_TRANSACCION.sql"

VALIDACION DEL ROLLBACK SIN QUITAR LA CORRECCION
sqlcmd -S "(localdb)\MSSQLLocalDB" -E -d FlexiForbesv2 -b -i ".\98_VALIDAR_ROLLBACK_EN_TRANSACCION.sql"

ROLLBACK
1. Detener nuevamente todos los escritores.
2. Ejecutar ROLLBACK\02, 03, 04 y 05 en ese orden.
3. Ejecutar ROLLBACK\06_ELIMINAR_SEQUENCE.sql.
4. Reactivar servicios y jobs.

ADVERTENCIA DEL ROLLBACK
El rollback restaura MAX + 1 y, por lo tanto, tambien restaura el riesgo de colision.

PROTECCION DE VERSION
00_PREVALIDAR.sql compara las definiciones con las versiones original y modificada
usadas para generar este ZIP. Si marca DIFERENTE, no ejecutar los ALTER: primero se
deben regenerar sobre las definiciones reales de ese ambiente.
