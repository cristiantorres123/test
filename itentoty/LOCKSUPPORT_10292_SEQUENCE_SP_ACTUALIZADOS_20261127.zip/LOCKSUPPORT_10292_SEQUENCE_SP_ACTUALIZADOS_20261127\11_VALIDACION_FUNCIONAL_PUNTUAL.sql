﻿USE [FlexiForbesv2];
GO

/*
PRUEBAS FUNCIONALES PUNTUALES

1. ff_VerificaExcedentes
   EXEC dbo.ff_VerificaExcedentes @idempleado = <ID_QA>, @idUsuario = <USUARIO_QA>;

2. FF_CALCULARCOMPENSACION
   Probar desde el flujo de cambio salarial que llama dbo.FF_CAMBIOSALARIO.
   No inventar parametros: usar un empleado y vigencia validos de QA.

3. ff_guardarCompensacionBonoAuto
   Probar desde Bono Auto BF3 con un empleado valido.

4. ff_CalculaExcedentes
   Solo probar si se confirma que sigue en uso; su encabezado indica NO ESTA EN USO.

Resultado esperado en todos los flujos que insertan:
- No aparece error 2601 ni 2627.
- CEIdCompensacionEmpleado no se repite.
- El monto y las reglas de negocio no cambian.
*/

DECLARE @Desde DATETIME = DATEADD(HOUR, -1, GETDATE());

-- CAT: Sustituir los IDs por los empleados realmente usados en la prueba.
DECLARE @Empleado1 INT = NULL;
DECLARE @Empleado2 INT = NULL;

SELECT
    CEIdCompensacionEmpleado,
    CEIdCompensacion,
    CEIdEmpleado,
    CETotalCreditos,
    CEFechaAdd
FROM dbo.ff_CompensacionEmpleado
WHERE CEFechaAdd >= @Desde
  AND CEIdEmpleado IN (@Empleado1, @Empleado2)
ORDER BY CEIdCompensacionEmpleado;

SELECT
    CEIdCompensacionEmpleado,
    COUNT(*) AS repeticiones
FROM dbo.ff_CompensacionEmpleado
GROUP BY CEIdCompensacionEmpleado
HAVING COUNT(*) > 1;
-- Resultado esperado: cero filas.
GO