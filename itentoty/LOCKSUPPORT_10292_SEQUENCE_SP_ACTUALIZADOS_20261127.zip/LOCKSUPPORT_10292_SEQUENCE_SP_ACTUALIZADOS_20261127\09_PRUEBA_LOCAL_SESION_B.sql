﻿USE [FlexiForbesv2];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;

-- CAT: Abrir esta prueba junto con la sesion opuesta y ejecutarlas casi al mismo tiempo.
IF CONVERT(NVARCHAR(128), SERVERPROPERTY('ServerName')) NOT LIKE N'%LOCALDB%'
    THROW 51310, 'Esta prueba solo se permite en LocalDB.', 1;

WAITFOR DELAY '00:00:05';

DECLARE @I INT = 1;
WHILE @I <= 500
BEGIN
    INSERT INTO dbo.CAT_PruebaSequence_10292 (Id, Sesion, SPID, Fecha)
    VALUES
    (
        NEXT VALUE FOR dbo.Seq_ff_CompensacionEmpleado,
        'B',
        @@SPID,
        SYSDATETIME()
    );
    SET @I += 1;
END;

SELECT 'B' AS sesion, COUNT(*) AS filasInsertadas
FROM dbo.CAT_PruebaSequence_10292
WHERE Sesion = 'B';
GO