﻿USE [FlexiForbesv2];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;

-- CAT: LO QUE SE HIZO FUE validar la BD antes de crear o alterar objetos.
IF TRY_CONVERT(INT, SERVERPROPERTY('ProductMajorVersion')) < 11
    THROW 51000, 'Se requiere SQL Server 2012 o superior para usar SEQUENCE.', 1;

IF OBJECT_ID(N'dbo.ff_CompensacionEmpleado', N'U') IS NULL
    THROW 51001, 'No existe dbo.ff_CompensacionEmpleado.', 1;

IF COL_LENGTH(N'dbo.ff_CompensacionEmpleado', N'CEIdCompensacionEmpleado') IS NULL
    THROW 51002, 'No existe CEIdCompensacionEmpleado.', 1;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.columns c
    WHERE c.object_id = OBJECT_ID(N'dbo.ff_CompensacionEmpleado')
      AND c.name = N'CEIdCompensacionEmpleado'
      AND TYPE_NAME(c.user_type_id) = N'int'
      AND c.is_identity = 0
)
    THROW 51003, 'CEIdCompensacionEmpleado debe ser INT y no IDENTITY.', 1;

DECLARE @Objetos TABLE (Objeto SYSNAME NOT NULL PRIMARY KEY);
INSERT INTO @Objetos (Objeto)
VALUES
    (N'dbo.ff_VerificaExcedentes'),
    (N'dbo.FF_CALCULARCOMPENSACION'),
    (N'dbo.ff_guardarCompensacionBonoAuto'),
    (N'dbo.ff_CalculaExcedentes');

IF EXISTS (SELECT 1 FROM @Objetos WHERE OBJECT_ID(Objeto, N'P') IS NULL)
BEGIN
    SELECT Objeto AS procedimientoFaltante
    FROM @Objetos
    WHERE OBJECT_ID(Objeto, N'P') IS NULL;
    THROW 51004, 'Falta al menos uno de los cuatro procedimientos.', 1;
END;

DECLARE @Versiones TABLE
(
    Objeto SYSNAME NOT NULL PRIMARY KEY,
    HashOriginal VARCHAR(64) NOT NULL,
    HashModificado VARCHAR(64) NOT NULL,
    HashRestaurado VARCHAR(64) NOT NULL
);
INSERT INTO @Versiones (Objeto, HashOriginal, HashModificado, HashRestaurado)
VALUES
    (N'dbo.ff_VerificaExcedentes', 'ADAFB3CB4D32918BB2E1991F1E246F8C728D822953A6D18F6FE456265EEB41A8', '9295172C7163224E157C55CDE414C0E7E332BD24D72E98D7F64614136972526F', '3E4EF01B18A9AADFD5BDC32449B634D01DEF5C1348F23EC8FA306C7730A3BD4C'),
    (N'dbo.FF_CALCULARCOMPENSACION', '6706B8E1EDFCAD0CBA636A7BFA619F5F2EA77BC9BF9C8255E02D62C84379E2F3', 'AB2C21EF016BFDD67E03642EA20ADCFF1F3E53890246FF313941379AEB2CA2B4', '635533C3DA39F3790342243B3785B151B23FBAC0752AA76A048EBC04367781E6'),
    (N'dbo.ff_guardarCompensacionBonoAuto', 'B610036AC5E1FB0CB200485780B0D74350647E37B935FABA7AC26102F1648E39', 'F9775F5A1D605B481AB3EBF2A7DDDB138E5CA4D6FB3B854553E74E520F479C5C', '92E977B9A1955CA644DBB06F87960B91736512E266E5817BC62107E9E8413862'),
    (N'dbo.ff_CalculaExcedentes', '6E293C774186AAD3F6E73495CB1F37AE15A7138F21FD40FC90BF0BA0DA7E351B', '5C1E7110E5F6EAB9AA00A249EEF21BC43C5FE1FE34881A3038C1AC44BD33DADE', 'A0F9FBDDB87EB0D1A7D7343E592B4E7F1725F1CAE513FD72F4A17C8BA3513F3D');

;WITH Actual AS
(
    SELECT
        V.Objeto,
        V.HashOriginal,
        V.HashModificado,
        V.HashRestaurado,
        CONVERT(VARCHAR(64), HASHBYTES
        (
            'SHA2_256',
            CONVERT(VARBINARY(MAX), M.definition)
        ), 2) AS HashActual
    FROM @Versiones V
    INNER JOIN sys.sql_modules M
        ON M.object_id = OBJECT_ID(V.Objeto)
)
SELECT
    Objeto,
    HashActual,
    CASE
        WHEN HashActual = HashOriginal THEN 'ORIGINAL'
        WHEN HashActual = HashModificado THEN 'MODIFICADO'
        WHEN HashActual = HashRestaurado THEN 'RESTAURADO'
        ELSE 'DIFERENTE'
    END AS estadoDefinicion
FROM Actual
ORDER BY Objeto;

IF EXISTS
(
    SELECT 1
    FROM @Versiones V
    INNER JOIN sys.sql_modules M
        ON M.object_id = OBJECT_ID(V.Objeto)
    CROSS APPLY
    (
        SELECT CONVERT(VARCHAR(64), HASHBYTES
        (
            'SHA2_256',
            CONVERT(VARBINARY(MAX), M.definition)
        ), 2) AS HashActual
    ) H
    WHERE H.HashActual NOT IN (V.HashOriginal, V.HashModificado, V.HashRestaurado)
)
    THROW 51005, 'Un SP difiere de la version usada para generar el ZIP. No aplicar estos ALTER.', 1;

SELECT
    CONVERT(NVARCHAR(128), SERVERPROPERTY('ServerName')) AS servidor,
    DB_NAME() AS baseDatos,
    CONVERT(NVARCHAR(128), SERVERPROPERTY('ProductVersion')) AS versionSql,
    (SELECT compatibility_level FROM sys.databases WHERE name = DB_NAME()) AS compatibilidad,
    (SELECT COUNT(*) FROM dbo.ff_CompensacionEmpleado) AS filasTabla,
    (SELECT ISNULL(MAX(CONVERT(BIGINT, CEIdCompensacionEmpleado)), 0)
     FROM dbo.ff_CompensacionEmpleado) AS maximoActual,
    (SELECT ISNULL(MAX(CONVERT(BIGINT, CEIdCompensacionEmpleado)), 0) + 1
     FROM dbo.ff_CompensacionEmpleado) AS siguienteCalculado,
    CASE WHEN OBJECT_ID(N'dbo.Seq_ff_CompensacionEmpleado', N'SO') IS NULL
         THEN 'NO EXISTE' ELSE 'EXISTE' END AS estadoSequence;

SELECT
    HAS_PERMS_BY_NAME(N'dbo', 'SCHEMA', 'CREATE SEQUENCE') AS puedeCrearSequence,
    HAS_PERMS_BY_NAME(N'dbo', 'SCHEMA', 'ALTER') AS puedeAlterarSchemaDbo,
    HAS_PERMS_BY_NAME(N'dbo.ff_VerificaExcedentes', 'OBJECT', 'ALTER') AS puedeAlterarVerifica,
    HAS_PERMS_BY_NAME(N'dbo.FF_CALCULARCOMPENSACION', 'OBJECT', 'ALTER') AS puedeAlterarCalcular,
    HAS_PERMS_BY_NAME(N'dbo.ff_guardarCompensacionBonoAuto', 'OBJECT', 'ALTER') AS puedeAlterarBono,
    HAS_PERMS_BY_NAME(N'dbo.ff_CalculaExcedentes', 'OBJECT', 'ALTER') AS puedeAlterarExcedentes;

-- CAT: Busca texto MAX + 1; ff_CalculaExcedentes puede aparecer por un comentario legado.
SELECT
    QUOTENAME(OBJECT_SCHEMA_NAME(M.object_id)) + N'.' +
    QUOTENAME(OBJECT_NAME(M.object_id)) AS referenciaTextualMaxMasUno
FROM sys.sql_modules M
CROSS APPLY
(
    SELECT LOWER(REPLACE(REPLACE(REPLACE(REPLACE
    (
        M.definition, N' ', N''
    ), CHAR(9), N''), CHAR(13), N''), CHAR(10), N'')) AS SinEspacios
) D
WHERE D.SinEspacios LIKE N'%max(ceidcompensacionempleado)+1%'
   OR D.SinEspacios LIKE N'%max(isnull(ceidcompensacionempleado,0))+1%'
ORDER BY referenciaTextualMaxMasUno;

PRINT 'PREVALIDACION_OK';
GO
