﻿USE [FlexiForbesv2];
GO

-- CAT: ROLLBACK: se restaura la definicion original de dbo.ff_guardarCompensacionBonoAuto.
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO


ALTER PROCEDURE [dbo].[ff_guardarCompensacionBonoAuto] (@id int,@idEmpleado int,@montoAsignado money)
AS
BEGIN
	DECLARE @montoFlex float,
	@idVigencia int,
	@fechaBono date,
	@fechaFinVigencia date,
	@montoA1 float,
	@mesesA1 int,
	@montoMes float,
	@montoMedios float,
	@mesesMedios int,
	@montoA5 float,
	@mesesA5 int,
	@idCompensacion int,
	@noRenovacion int,
	@varMonto1 float,
	@enrollmentResult INT,
	@interVigenciaResult INT,
	@fechaActual DATETIME,
	@idEmpresa AS INT =0


  SELECT
    @montoFlex = CAST((CAMontoBonoAuto - @montoAsignado) / ISNULL((1 - CAST(ISNULL(CAPorcentaje, 0) AS float) / CAST(100 AS float)), 1) AS float),
    @idVigencia = CAIdVigenciaBeneficios,
    @fechaBono = CAFechaInicial,
    @idCompensacion = CAIdCompensacion,
    @noRenovacion = CANoRenovacion,
    @varMonto1 = CAST(CAMontoA1 AS float)
  FROM ff_CompensacionAuto
  WHERE CAId = @id
  AND CAIdEmpleado = @idEmpleado
  AND CAEstatus = 1


  IF EXISTS (SELECT CAIdEmpleado FROM ff_CompensacionAuto WHERE CAId = @id AND CAIdEmpleado = @idEmpleado  AND CAEstatus = 1)
  BEGIN
    IF (ISNULL(@varMonto1, 0) = 0)
    BEGIN

      SELECT
        @fechaFinVigencia = VIVigenciaFin
      FROM ff_Vigencia
      WHERE VIidVigencia = @idVigencia

      --set @fechaFinVigencia = '2022-01-01';
      SET @mesesA1 = DATEDIFF(M, @fechaBono, @fechaFinVigencia);

      -- 48 meses que dura el bono, de esta forma sacamos el monto por mes para poder calcular los totales
      SET @montoMes = CAST(@montoFlex AS float) / CAST(48 AS float);

      IF (@mesesA1 = 12)
      BEGIN
        -- cuando el bono es simetrico, no tendra monto ni fecha A5
        SET @montoA1 = CAST(@montoMes AS float) * CAST(@mesesA1 AS float);
        SET @montoMedios = CAST(@montoA1 AS float);
        SET @mesesMedios = @mesesA1;


        UPDATE ff_CompensacionAuto
        SET CAMontoAsignado = @montoAsignado,
            CAMontoUtilizadoFlex = @montoFlex,
            CAMontoA1 = @montoA1,
            CAMesesA1 = @mesesA1,
            CAMontoA2 = @montoMedios,
            CaMesesA2 = @mesesMedios,
            CAMontoA3 = @montoMedios,
            CAMesesA3 = @mesesMedios,
            CAMontoA4 = @montoMedios,
            CAMesesA4 = @mesesMedios,
            CAEstatusConfirmacion = 2,
            CAUserMod = @idEmpleado,
            CAFechaMod = GETDATE()
        WHERE CAId = @id
        AND CAIdEmpleado = @idEmpleado
        AND CAEstatus = 1

      --insert into ff_CompensacionEmpleado values (@idCompensacion, @idEmpleado, @montoA1, 1,@idEmpleado, GETDATE())

      END
      ELSE
      BEGIN
        -- cuando el bono es asimetrico, tendra que calcular monto y fecha A5

        SET @montoA1 = CAST(@montoMes AS float) * CAST(@mesesA1 AS float);
        SET @mesesMedios = 12;
        SET @montoMedios = CAST(@montoMes AS float) * CAST(@mesesMedios AS float);

        SET @mesesA5 = 12 - @mesesA1;
        SET @montoA5 = CAST(@montoMes AS float) * CAST(@mesesA5 AS float);



        IF (@noRenovacion > 1)
        BEGIN
          SET @montoA1 = @montoA1 + ISNULL((SELECT
            CAMontoA5
          FROM ff_CompensacionAuto
          WHERE CAIdEmpleado = @idEmpleado
          AND CANoRenovacion = (@noRenovacion - 1)
          AND CAEstatusConfirmacion = 2)
          , 0)
        END

        UPDATE ff_CompensacionAuto
        SET CAMontoAsignado = @montoAsignado,
            CAMontoUtilizadoFlex = @montoFlex,
            CAMontoA1 = @montoA1,
            CAMesesA1 = @mesesA1,
            CAMontoA2 = @montoMedios,
            CaMesesA2 = @mesesMedios,
            CAMontoA3 = @montoMedios,
            CAMesesA3 = @mesesMedios,
            CAMontoA4 = @montoMedios,
            CAMesesA4 = @mesesMedios,
            CAMontoA5 = @montoA5,
            CAMesesA5 = @mesesA5,
            CAEstatusConfirmacion = 2,
            CAUserMod = @idEmpleado,
            CAFechaMod = GETDATE()
        WHERE CAId = @id
        AND CAIdEmpleado = @idEmpleado
        AND CAEstatus = 1

      --insert into ff_CompensacionEmpleado values (@idCompensacion, @idEmpleado, @montoA1, 1, @idEmpleado, GETDATE())



      END

      DECLARE @idCompensacionEmpleado int;
      SELECT
        @idCompensacionEmpleado = (MAX(CEidCompensacionEmpleado) + 1)
      FROM ff_CompensacionEmpleado

      IF EXISTS (SELECT CEidCompensacion FROM ff_CompensacionEmpleado WHERE CEidCompensacion = @idCompensacion AND CEidEmpleado = @idEmpleado AND CEidEstatus = 1)
      BEGIN
        PRINT 'update compensacion'
        UPDATE ff_CompensacionEmpleado
        SET CETotalCreditos = @montoA1,
            CEUsuarioUMod = @idEmpleado,
            CEFechaUMod = GETDATE()
        WHERE CEidCompensacion = @idCompensacion
        AND CEidEmpleado = @idEmpleado
        AND CEidEstatus = 1
      END
      ELSE
      BEGIN
        PRINT 'insert compensacion'
        INSERT INTO ff_CompensacionEmpleado
          VALUES (@idCompensacionEmpleado, @idCompensacion, @idEmpleado, @montoA1, 1, @idEmpleado, GETDATE(), NULL, NULL, NULL, NULL)
      END

      --insert into ff_CompensacionEmpleado values (@idCompensacionEmpleado, @idCompensacion, @idEmpleado, @montoA1, 1, @idEmpleado, GETDATE(), null,null,null,null)
	  	SELECT
			@idEmpresa = EMIdEmpresa,
			@fechaActual = GETDATE()
		FROM ff_Empleado WHERE ID = @idEmpleado


			SELECT 
				@interVigenciaResult =
				CASE
					WHEN GETDATE() >= VIVigenciaIni AND GETDATE() <= VIVigenciaFin
						THEN 1
					ELSE 0
					END,
				@enrollmentResult =
				CASE
					WHEN GETDATE() >= VIEnrollmentIni AND GETDATE() <= VIEnrollmentFin
						THEN 1
					ELSE 0
				END
			FROM ff_Vigencia A1
			INNER JOIN ff_Empresa A2 ON(A1.viidConfiguracion = A2.EMidConfiguracion)
			WHERE A2.EMIdEmpresa = @idEmpresa
			AND A1.viidEstatus in (1, 6)
     
	 
	
		 DECLARE 
		 @ValidacionBonoAuto AS TABLE(resultado INT)
		 
		 INSERT INTO @ValidacionBonoAuto
		 EXEC st_ff_validacionPlanesBonoAuto @idEmpleado

		 IF (SELECT resultado FROM @ValidacionBonoAuto) = 1
		 BEGIN
			UPDATE ff_CompensacionAuto SET TieneSolicitudAuto = 1
			WHERE CAId = @id 
			AND CAIdEmpleado = @idEmpleado
		 END
	 
		--IF EXISTS (SELECT CAMontoBonoAuto FROM ff_CompensacionAuto WHERE CAIdEmpleado =@idEmpleado AND CAId =@id AND CAMontoBonoAuto = @montoAsignado)
		----AND @enrollmentResult =0											
		----Regla 1: Cuando el Monto Asignado es igual al monto total*															
		--AND @interVigenciaResult <> 1
		--	OR
		--	 --Regla 2: Cuando el Monto Total es diferente al monto asignado y est es mayor que 0*
		--EXISTS(SELECT CAMontoBonoAuto FROM ff_CompensacionAuto WHERE CAIdEmpleado =@idEmpleado AND CAId =@id AND CAMontoBonoAuto <> @montoAsignado  AND @montoAsignado >0)
		--	OR 
		--	 --Regla 3: Cuando el Monto Asignado es igual a 0*
		--EXISTS(SELECT CAMontoBonoAuto FROM ff_CompensacionAuto WHERE CAIdEmpleado =@idEmpleado AND CAId =@id AND  @montoAsignado =0)
	 -- BEGIN
		--	UPDATE ff_CompensacionAuto SET TieneSolicitudAuto = 1
		--	WHERE CAId = @id 
		--	AND CAIdEmpleado = @idEmpleado
	 -- END

		EXEC ff_leyendaCompensacionBonoAuto @idEmpleado,@id

    END

  END
END

GO

PRINT 'OK: dbo.ff_guardarCompensacionBonoAuto restaurado';
GO