﻿USE [FlexiForbesv2];
GO
SET NOCOUNT ON;

-- CAT: Ejecutar este archivo solo despues de restaurar los cuatro SP originales.
IF OBJECT_ID(N'dbo.Seq_ff_CompensacionEmpleado', N'SO') IS NOT NULL
BEGIN
    IF EXISTS
    (
        SELECT 1
        FROM sys.sql_expression_dependencies
        WHERE referenced_id = OBJECT_ID(N'dbo.Seq_ff_CompensacionEmpleado')
    )
    BEGIN
        SELECT
            QUOTENAME(OBJECT_SCHEMA_NAME(referencing_id)) + N'.' +
            QUOTENAME(OBJECT_NAME(referencing_id)) AS dependenciaPendiente
        FROM sys.sql_expression_dependencies
        WHERE referenced_id = OBJECT_ID(N'dbo.Seq_ff_CompensacionEmpleado');
        THROW 51400, 'No se elimina la SEQUENCE porque todavia tiene dependencias.', 1;
    END;

    DROP SEQUENCE dbo.Seq_ff_CompensacionEmpleado;
    PRINT 'OK: sequence eliminada.';
END
ELSE
    PRINT 'OK: la sequence ya no existe.';
GO