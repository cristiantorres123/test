:ON ERROR EXIT

-- CAT: LO QUE SE HIZO FUE reunir la instalacion completa para sqlcmd.
-- CAT: Este archivo aplica los cambios de forma permanente en LocalDB.
:r .\00_PREVALIDAR.sql
:r .\01_CREAR_SINCRONIZAR_SEQUENCE.sql
:r .\02_ALTER_ff_VerificaExcedentes.sql
:r .\03_ALTER_FF_CALCULARCOMPENSACION.sql
:r .\04_ALTER_ff_guardarCompensacionBonoAuto.sql
:r .\05_ALTER_ff_CalculaExcedentes.sql
:r .\06_VALIDAR_INSTALACION.sql

PRINT 'INSTALACION_LOCALDB_OK';
GO
