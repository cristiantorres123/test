﻿USE [FlexiForbesv2];
GO
SET NOCOUNT ON;

-- CAT: LO QUE SE HIZO FUE validar la SEQUENCE y los nueve reemplazos.
IF OBJECT_ID(N'dbo.Seq_ff_CompensacionEmpleado', N'SO') IS NULL
    THROW 51200, 'No existe dbo.Seq_ff_CompensacionEmpleado.', 1;

DECLARE @Maximo BIGINT =
(
    SELECT ISNULL(MAX(CONVERT(BIGINT, CEIdCompensacionEmpleado)), 0)
    FROM dbo.ff_CompensacionEmpleado
);
DECLARE @Actual BIGINT;

SELECT @Actual = CONVERT(BIGINT, COALESCE(current_value, start_value))
FROM sys.sequences
WHERE object_id = OBJECT_ID(N'dbo.Seq_ff_CompensacionEmpleado');

IF @Actual <= @Maximo
    THROW 51201, 'La SEQUENCE no esta por delante del maximo de la tabla.', 1;

IF EXISTS
(
    SELECT 1
    FROM sys.sequences
    WHERE object_id = OBJECT_ID(N'dbo.Seq_ff_CompensacionEmpleado')
      AND
      (
          TYPE_NAME(user_type_id) <> N'int'
          OR CONVERT(BIGINT, increment) <> 1
          OR is_cycling = 1
      )
)
    THROW 51202, 'La configuracion de la SEQUENCE no es valida.', 1;

DECLARE @Esperado TABLE
(
    Objeto SYSNAME NOT NULL PRIMARY KEY,
    UsosEsperados INT NOT NULL
);
INSERT INTO @Esperado (Objeto, UsosEsperados)
VALUES
    (N'dbo.ff_VerificaExcedentes', 6),
    (N'dbo.FF_CALCULARCOMPENSACION', 1),
    (N'dbo.ff_guardarCompensacionBonoAuto', 1),
    (N'dbo.ff_CalculaExcedentes', 1);

;WITH Conteo AS
(
    SELECT
        E.Objeto,
        E.UsosEsperados,
        (LEN(LOWER(M.definition)) - LEN(REPLACE
        (
            LOWER(M.definition),
            N'next value for dbo.seq_ff_compensacionempleado',
            N''
        ))) / LEN(N'next value for dbo.seq_ff_compensacionempleado') AS UsosReales
    FROM @Esperado E
    INNER JOIN sys.sql_modules M
        ON M.object_id = OBJECT_ID(E.Objeto)
)
SELECT Objeto, UsosEsperados, UsosReales,
       CASE WHEN UsosEsperados = UsosReales THEN 'OK' ELSE 'ERROR' END AS resultado
FROM Conteo
ORDER BY Objeto;

IF EXISTS
(
    SELECT 1
    FROM @Esperado E
    INNER JOIN sys.sql_modules M
        ON M.object_id = OBJECT_ID(E.Objeto)
    CROSS APPLY
    (
        SELECT (LEN(LOWER(M.definition)) - LEN(REPLACE
        (
            LOWER(M.definition),
            N'next value for dbo.seq_ff_compensacionempleado',
            N''
        ))) / LEN(N'next value for dbo.seq_ff_compensacionempleado') AS UsosReales
    ) C
    WHERE C.UsosReales <> E.UsosEsperados
)
    THROW 51203, 'La cantidad de reemplazos no coincide con la esperada.', 1;

DECLARE @Definiciones TABLE
(
    Objeto SYSNAME NOT NULL PRIMARY KEY,
    SinEspacios NVARCHAR(MAX) NOT NULL
);

INSERT INTO @Definiciones (Objeto, SinEspacios)
SELECT
    E.Objeto,
    LOWER(REPLACE(REPLACE(REPLACE(REPLACE
    (
        M.definition,
        N' ', N''
    ), CHAR(9), N''), CHAR(13), N''), CHAR(10), N''))
FROM @Esperado E
INNER JOIN sys.sql_modules M
    ON M.object_id = OBJECT_ID(E.Objeto);

SELECT Objeto AS objetoConMaxMasUno
FROM @Definiciones
WHERE SinEspacios LIKE N'%set@maxcom=(selectmax(ceidcompensacionempleado)+1from%'
   OR SinEspacios LIKE N'%select@v_seq_compensacionempleado=max(isnull(ceidcompensacionempleado,0))+1from%'
   OR SinEspacios LIKE N'%@idcompensacionempleado=(max(ceidcompensacionempleado)+1)%';

IF EXISTS
(
    SELECT
        1
    FROM @Definiciones
    WHERE SinEspacios LIKE N'%set@maxcom=(selectmax(ceidcompensacionempleado)+1from%'
       OR SinEspacios LIKE N'%select@v_seq_compensacionempleado=max(isnull(ceidcompensacionempleado,0))+1from%'
       OR SinEspacios LIKE N'%@idcompensacionempleado=(max(ceidcompensacionempleado)+1)%'
)
    THROW 51204, 'Todavia existe al menos un generador MAX + 1 activo.', 1;

SELECT
    S.name AS sequenceNombre,
    TYPE_NAME(S.user_type_id) AS tipo,
    CONVERT(BIGINT, S.current_value) AS valorActual,
    @Maximo AS maximoTabla,
    CONVERT(BIGINT, S.increment) AS incremento,
    S.is_cycling AS usaCycle,
    S.cache_size AS cacheSize
FROM sys.sequences S
WHERE S.object_id = OBJECT_ID(N'dbo.Seq_ff_CompensacionEmpleado');

SELECT
    QUOTENAME(OBJECT_SCHEMA_NAME(D.referencing_id)) + N'.' +
    QUOTENAME(OBJECT_NAME(D.referencing_id)) AS objetoDependiente
FROM sys.sql_expression_dependencies D
WHERE D.referenced_id = OBJECT_ID(N'dbo.Seq_ff_CompensacionEmpleado')
ORDER BY objetoDependiente;

PRINT 'VALIDACION_OK';
GO
