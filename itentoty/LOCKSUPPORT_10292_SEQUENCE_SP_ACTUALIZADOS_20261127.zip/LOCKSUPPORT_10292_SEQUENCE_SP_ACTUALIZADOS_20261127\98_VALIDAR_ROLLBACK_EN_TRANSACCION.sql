:ON ERROR EXIT
USE [FlexiForbesv2];
GO

-- CAT: LO QUE SE HIZO FUE probar el rollback sin quitar la correccion de LocalDB.
BEGIN TRANSACTION;
GO
:r .\ROLLBACK\02_RESTAURAR_ff_VerificaExcedentes.sql
:r .\ROLLBACK\03_RESTAURAR_FF_CALCULARCOMPENSACION.sql
:r .\ROLLBACK\04_RESTAURAR_ff_guardarCompensacionBonoAuto.sql
:r .\ROLLBACK\05_RESTAURAR_ff_CalculaExcedentes.sql
:r .\ROLLBACK\06_ELIMINAR_SEQUENCE.sql
:r .\00_PREVALIDAR.sql
ROLLBACK TRANSACTION;
GO

-- CAT: Despues del ROLLBACK de la prueba, la correccion debe seguir instalada.
:r .\06_VALIDAR_INSTALACION.sql
PRINT 'PRUEBA_ROLLBACK_TRANSACCIONAL_OK';
GO
