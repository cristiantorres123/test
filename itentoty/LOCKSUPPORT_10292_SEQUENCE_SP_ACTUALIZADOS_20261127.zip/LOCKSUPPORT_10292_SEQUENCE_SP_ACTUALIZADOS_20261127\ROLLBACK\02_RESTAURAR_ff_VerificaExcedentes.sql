﻿USE [FlexiForbesv2];
GO

-- CAT: ROLLBACK: se restaura la definicion original de dbo.ff_VerificaExcedentes.
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO






--MOD 03112006 BAT Se agrega para que calcule Excedentes en base a la zona.

-- SEP 06
ALTER PROCEDURE [dbo].[ff_VerificaExcedentes] (@idempleado int, @idUsuario int)  --22459
AS            
BEGIN 
--  dbo.ff_VerificaExcedentes 23892, 7
-- dbo.ff_VerificaExcedentes 474804, 5
-- dbo.ff_VerificaExcedentes 22978, 5

Declare @COAjustaSueldoCto int
Declare @ccidVigencia int
declare @ccidcompensacion int,
	@emsalariobase money, 
	@emvalesp money, 
	@emfondoahorrop money,
	@tope_vales MONEY,
	@tope_vales_UMA MONEY,
	@tope_fondo MONEY,
	@tope_fondo_UMA MONEY,
	@CalcVales MONEY,
	@CalcFA MONEY,
	@ExcedentesFinales MONEY,
 	@Excedenteant Money,
	@maxCom INT,
	@idCorporativo INT,
	@idEmpresa INT,
	@NumMax INT,
	@emOficina INT, --mod BAT 03112006
	@zonaeconomica INT, --mod BAT 03112006
	@IdConfiguracion INT, --mod BAT 03112006
	@SalarioMinino  MONEY, --mod BAT 03112006
	@EmfechaIngreso DATETIME,
	@ccidcompensacionDifTipo INT --mod BAT 12092016
	


		set @idUsuario = ISNULL(@idUsuario,@idempleado)
		select @idEmpresa = emidempresa, @EmfechaIngreso= emfechaingresoempresa  from dbo.ff_empleado with (nolock, readuncommitted) where id = @idempleado

		--Obtengo vigencia
		select @ccidVigencia = ViidVigencia from dbo.ff_vigencia with (nolock, readuncommitted) where VITipoNegocio=1 AND viidestatus in (6, 1) and viidconfiguracion =  (select emidconfiguracion from dbo.ff_empresa with (nolock, readuncommitted)
			where emidempresa = @idEmpresa)
		
		--Obtengo compensación
		select @ccidcompensacion = isnull(ccidcompensacion,0)  from dbo.ff_CompensacionConfiguracion WITH (NOLOCK,READUNCOMMITTED)
			where ccexcedente = 1 and ccidvigencia = @ccidVigencia and ccidperfil = (select emidperfil from dbo.ff_empleado   WITH (NOLOCK,READUNCOMMITTED) where id = @idempleado)	

		--mod bat 12092016	-- Compensación fija durante todo el año
		select @ccidcompensacionDifTipo = isnull(ccidcompensacion,0),@ExcedentesFinales =ISNULL(CCMontoFijo,0)  from dbo.ff_CompensacionConfiguracion WITH (NOLOCK,READUNCOMMITTED)
		where ccexcedente = 0 and CCidFormulaCalculo=8 and ccidvigencia = @ccidVigencia and ccidperfil = (select emidperfil from dbo.ff_empleado   WITH (NOLOCK,READUNCOMMITTED) where id = @idempleado)	
		
		--select @ccidVigencia 
		--Obtengo compensación
		--select @ccidcompensacion
	set @ExcedentesFinales= ISNULL(@ExcedentesFinales,0)
	set @ccidcompensacionDifTipo =  ISNULL(@ccidcompensacionDifTipo,0)
	set @ccidcompensacion=ISNULL(@ccidcompensacion,0)

	if ( @ccidcompensacion > 0 OR @ccidcompensacionDifTipo > 0) AND @ccidcompensacion<>211--Hay compensación de excedentes 
	begin
				--calculo excedentes
-- MOD BAT 03112006		       SELECT @emsalariobase= isnull(emSalariobase,0), @emvalesp= ISNULL(emvalesp,0), @emfondoahorrop = ISNULL(emfondoahorrop,0), 
		       SELECT @emsalariobase= isnull(emSalariobase,0), @emvalesp= ISNULL(emvalesp,0), @emfondoahorrop = ISNULL(emfondoahorrop,0), @emOficina=ISNULL(emOficina,0),  
					@idEmpresa = emidempresa,@EmfechaIngreso=EMFechaIngresoEmpresa 
    				FROM dbo.ff_empleado  WITH (NOLOCK,READUNCOMMITTED)
				WHERE  id = @idempleado
				and emidestatus = 1
				and emIdParentesco=1

				--Obtengo corporativo
				select @idCorporativo = EmidCorporativo,@IdConfiguracion=emIdConfiguracion from ff_EMPRESA WITH (NOLOCK,READUNCOMMITTED) WHERE EMIDEMPRESA = @idEmpresa

				 --SELECT @emsalariobase, @emvalesp, @emfondoahorrop, @idCorporativo

    		IF (@emsalariobase) > 0
    		BEGIN 
--MOD BAT 03112006 
				SET @zonaeconomica = ISNULL((SELECT ISNULL(teidzonaeconomica,1)FROM  ff_tablaencabezadodetalle,ff_tablaEncabezado
                		WHERE ENIdEmpresa=@IdEmpresa AND ENClave= TEEnClave and TEIdDetalle=@emOficina), 
				(SELECT cozonaeconomica FROM ff_configuracion C WHERE c.COidconfiguracion=@IdConfiguracion))
				SELECT @SalarioMinino= ISNULL(ZESalarioMinimo,30000) FROM  ff_zonaeconomica WHERE ZEIdZonaEconomica= @zonaeconomica

				--select @zonaeconomica
				--print '@zonaeconomica'
				IF @idEmpresa = 369  
				BEGIN
				--DELETE bf_Compensacion_STEmpleado WHERE CSIdEmpleado = @idempleado AND CSIdCompensacion in(SELECT ceidcompensacion FROM ff_CompensacionEmpleado WHERE CEidEmpleado= @idempleado) MOD 24032007
				DELETE bf_Compensacion_STEmpleado WHERE CSIdEmpleado = @idempleado AND CSIdCompensacion IN(191,192,193,190,175,176,177,178,358,359,466,170)--MOD DB 27-03-2020 se arego 358,359
				--select @zonaeconomica=(SELECT ISNULL(teidzonaeconomica,1) from ff_empleado inner join ff_TablaEncabezadoDetalle on EMOficina=TEIdDetalle and TEidEstatus=1
				--where id=@idempleado)
				--mod DB
				SET  @tope_vales = 3153.70
				SET  @tope_fondo = 4102.05
				SET  @emvalesp=.145
				SET  @emfondoahorrop = .12

				if (@zonaeconomica=2)
				begin
				SET  @tope_vales_UMA = 7967.46
				SET  @tope_fondo_UMA = 12353.21
				end
				else 
				begin
				SET  @tope_vales_UMA = 5290.72
				SET  @tope_fondo_UMA = 8202.52
				end
				/*if (@zonaeconomica=2)
				begin
				SET  @tope_vales = 2606.00
				SET  @tope_fondo = 3435.38
				SET  @emvalesp=.145
				SET  @emfondoahorrop = .12
				end
				else 
				begin
				SET  @tope_vales = 2606.00
				SET  @tope_fondo = 3435.38
				SET  @emvalesp=.145
				SET  @emfondoahorrop = .12
				end	*/
				-- 175 Vales Compensacion
				Declare @contador int, @dias int,@ValorCS MONEY
				SET @contador=175
				WHILE (@contador < 179 )
				BEGIN
				SET @ccidcompensacion = @contador
				
				if @contador =175
				BEGIN
				SET @ExcedentesFinales = CASE WHEN (@emvalesp*@emsalariobase*12)<=(@tope_vales*12) THEN (@emvalesp*@emsalariobase*12) ELSE @tope_vales *12 END
				SET @ValorCS = @ExcedentesFinales-1200
				INSERT INTO [bf_Compensacion_STEmpleado]([CSIdEmpleado],[CSIdCompensacion],[CSMontoCompensacion],[CSIdEstatus],[CSUsuarioAdd],[CSFechaAdd],[CSUsuarioUmod],[CSFechaUmod])
			    VALUES (@idempleado,191,1200, 1,@idUsuario, getdate(), @idUsuario, getdate())	
				END
				if @contador =176
				BEGIN
				SET @ExcedentesFinales = CASE WHEN (@emfondoahorrop*@emsalariobase*12)<=(@tope_fondo*12) THEN (@emfondoahorrop*@emsalariobase*12) ELSE @tope_fondo*12 END
				SET @ValorCS = @ExcedentesFinales-1200
				INSERT INTO [bf_Compensacion_STEmpleado]([CSIdEmpleado],[CSIdCompensacion],[CSMontoCompensacion],[CSIdEstatus],[CSUsuarioAdd],[CSFechaAdd],[CSUsuarioUmod],[CSFechaUmod])
			    VALUES (@idempleado,192,1200, 1,@idUsuario, getdate(), @idUsuario, getdate())	
				END
				if @contador =178
				BEGIN
				IF YEAR(@EmfechaIngreso)=YEAR(GETDATE())
					BEGIN
						SET @ExcedentesFinales = (((@emsalariobase/30)* 15)/365)*(DATEDIFF (dd,@EmfechaIngreso,CAST(YEAR(GETDATE()) AS VARCHAR(4))+'-12-31')+1)
						INSERT INTO [bf_Compensacion_STEmpleado]([CSIdEmpleado],[CSIdCompensacion],[CSMontoCompensacion],[CSIdEstatus],[CSUsuarioAdd],[CSFechaAdd],[CSUsuarioUmod],[CSFechaUmod])
						VALUES (@idempleado,190,ISNULL(@emsalariobase/2,0), 1,@idUsuario, getdate(), @idUsuario, getdate())	
					END
					ELSE
					BEGIN
						SET @ExcedentesFinales = (@emsalariobase/30)*15 
						INSERT INTO [bf_Compensacion_STEmpleado]([CSIdEmpleado],[CSIdCompensacion],[CSMontoCompensacion],[CSIdEstatus],[CSUsuarioAdd],[CSFechaAdd],[CSUsuarioUmod],[CSFechaUmod])
						VALUES (@idempleado,190,ISNULL(@ExcedentesFinales,0), 1,@idUsuario, getdate(), @idUsuario, getdate())	
					END
				END
				if @contador =177 
				BEGIN
				DECLARE @Vig_Inicio DATETIME
				SET @Vig_Inicio= (SELECT VIVigenciaIni from ff_Vigencia where VIidVigencia=@ccidVigencia)
				SET @dias = ISNULL((SELECT dbo.RegresaEdad(@EmfechaIngreso,CASE WHEN @Vig_Inicio<GETDATE() THEN GETDATE() ELSE @Vig_Inicio END)),12)
				SET @ExcedentesFinales = (@emsalariobase/30) * (SELECT PPPorcentajeEmpresa*PPDiasVacacionesEmpresa FROM bf_PorcentajePrimaVacacional where PPIdEstatus=1 and PPIdEmpresa=@idCorporativo AND @dias between PPAnioServicioMin AND ISNULL(PPAnioServicioMax,PPAnioServicioMin))
				SET @ValorCS = @ExcedentesFinales-((@emsalariobase/30) *(SELECT .25*PPDiasVacacionesEmpresa FROM bf_PorcentajePrimaVacacional where PPIdEstatus=1 and PPIdEmpresa=@idCorporativo AND @dias between PPAnioServicioMin AND ISNULL(PPAnioServicioMax,PPAnioServicioMin)))
				INSERT INTO [bf_Compensacion_STEmpleado]([CSIdEmpleado],[CSIdCompensacion],[CSMontoCompensacion],[CSIdEstatus],[CSUsuarioAdd],[CSFechaAdd],[CSUsuarioUmod],[CSFechaUmod])
			    VALUES (@idempleado,193,ISNULL((@ExcedentesFinales-@ValorCS),0), 1,@idUsuario, getdate(), @idUsuario, getdate())	
								
				END
				--PRINT 'SMNYL'
				--print @EmfechaIngreso
				--print 	@dias
				--print 	@ccidcompensacion	
				--print @ExcedentesFinales
				SET @Excedenteant =ISNULL((SELECT CETotalCreditos FROM dbo.ff_compensacionempleado  WITH (NOLOCK,READUNCOMMITTED) WHERE  ceidempleado = @idempleado and CEidCompensacion = @ccidcompensacion ),-1)		
					IF (@Excedenteant >= 0)
                	BEGIN 
                		set @ValorCS = ISNULL(@ValorCS,0)
				       UPDATE  dbo.ff_compensacionempleado SET  cetotalcreditos=@ExcedentesFinales, CEUsuarioUMod = @idUsuario, CEFechaUMod = getdate(), CEidEstatus = 1
						WHERE ceidempleado = @idempleado AND CEidCompensacion = @ccidcompensacion
						if @ccidcompensacion NOT IN(178,177)
						BEGIN
						INSERT INTO [bf_Compensacion_STEmpleado]([CSIdEmpleado],[CSIdCompensacion],[CSMontoCompensacion],[CSIdEstatus],[CSUsuarioAdd],[CSFechaAdd],[CSUsuarioUmod],[CSFechaUmod])
			         	VALUES (@idempleado,@ccidcompensacion,ISNULL(@ValorCS,0), 1,@idUsuario, getdate(), @idUsuario, getdate())	
			         	END
			         	ELSE IF @ccidcompensacion=177
						BEGIN
						INSERT INTO [bf_Compensacion_STEmpleado]([CSIdEmpleado],[CSIdCompensacion],[CSMontoCompensacion],[CSIdEstatus],[CSUsuarioAdd],[CSFechaAdd],[CSUsuarioUmod],[CSFechaUmod])
			         	VALUES (@idempleado,@ccidcompensacion,ISNULL(@ExcedentesFinales,0), 1,@idUsuario, getdate(), @idUsuario, getdate())	
			         	END
			         	ELSE IF @ccidcompensacion=178
			         	BEGIN
			         	INSERT INTO [bf_Compensacion_STEmpleado]([CSIdEmpleado],[CSIdCompensacion],[CSMontoCompensacion],[CSIdEstatus],[CSUsuarioAdd],[CSFechaAdd],[CSUsuarioUmod],[CSFechaUmod])
			         	VALUES (@idempleado,@ccidcompensacion,ISNULL(@emsalariobase/2,0), 1,@idUsuario, getdate(), @idUsuario, getdate())	
						END
						INSERT dbo.ff_compensacionempleadohist (ceidcompensacion, ceidempleado, cetotalcreditos, CEidEstatus, CEUsuarioAdd, CEFechaAdd, CEUsuarioUMod, CEFechaUMod)
			         	VALUES (@ccidcompensacion,@idempleado,@Excedenteant, 1,@idUsuario, getdate(), @idUsuario, getdate())
        			END
					ELSE
					BEGIN
						SET @maxCom = (SELECT MAX (ceidcompensacionempleado) + 1 FROM dbo.ff_compensacionempleado  WITH (NOLOCK,READUNCOMMITTED))
									INSERT dbo.ff_compensacionempleado (ceidcompensacionempleado, ceidcompensacion, ceidempleado, cetotalcreditos, CEidEstatus, CEUsuarioAdd, CEFechaAdd, CEUsuarioUMod, CEFechaUMod)
                       			VALUES (@maxCom,@ccidcompensacion,@idempleado,@ExcedentesFinales, 1,@idUsuario, getdate(), @idUsuario, getdate())	   	               
							if @ccidcompensacion NOT IN(178,177)
							BEGIN
							INSERT INTO [bf_Compensacion_STEmpleado]([CSIdEmpleado],[CSIdCompensacion],[CSMontoCompensacion],[CSIdEstatus],[CSUsuarioAdd],[CSFechaAdd],[CSUsuarioUmod],[CSFechaUmod])
			         		VALUES (@idempleado,@ccidcompensacion,ISNULL(@ExcedentesFinales-1200,0), 1,@idUsuario, getdate(), @idUsuario, getdate())	
							END
							ELSE
							BEGIN
							INSERT INTO [bf_Compensacion_STEmpleado]([CSIdEmpleado],[CSIdCompensacion],[CSMontoCompensacion],[CSIdEstatus],[CSUsuarioAdd],[CSFechaAdd],[CSUsuarioUmod],[CSFechaUmod])
			         		VALUES (@idempleado,@ccidcompensacion,ISNULL(@ExcedentesFinales,0), 1,@idUsuario, getdate(), @idUsuario, getdate())	
							END
							INSERT dbo.ff_compensacionempleadohist ( ceidcompensacion, ceidempleado, cetotalcreditos, CEidEstatus, CEUsuarioAdd, CEFechaAdd, CEUsuarioUMod, CEFechaUMod)
			   			     VALUES (@ccidcompensacion,@idempleado,@Excedenteant, 1,@idUsuario, getdate(), @idUsuario, getdate())
					END
					SET @contador = @contador+1
				END

				--Mod DB Se agrega complemento
				Declare @contador2 int,@ValorCS2 MONEY
				SET @contador2=358
				WHILE (@contador2 < 360 )
				BEGIN
				SET @ccidcompensacion = @contador2
				if @contador2 =359
				BEGIN
				SET @ExcedentesFinales = CASE WHEN (@emvalesp*@emsalariobase*12)<=(@tope_vales*12) THEN 0
											WHEN (@emvalesp*@emsalariobase*12)>(@tope_vales_UMA*12) THEN (@tope_vales_UMA-@tope_vales)*12
											ELSE (@emvalesp*@emsalariobase*12)-(@tope_vales*12) END
				SET @ValorCS = @ExcedentesFinales
				IF (@ExcedentesFinales>0)
				BEGIN
				INSERT INTO [bf_Compensacion_STEmpleado]([CSIdEmpleado],[CSIdCompensacion],[CSMontoCompensacion],[CSIdEstatus],[CSUsuarioAdd],[CSFechaAdd],[CSUsuarioUmod],[CSFechaUmod])
			    VALUES (@idempleado,359,ISNULL(@ExcedentesFinales,0), 1,@idUsuario, getdate(), @idUsuario, getdate())	
				END
				END
				if @contador2 =358
				BEGIN
				SET @ExcedentesFinales = CASE WHEN (@emfondoahorrop*@emsalariobase*12)<=(@tope_fondo*12) THEN 0 
											WHEN (@emfondoahorrop*@emsalariobase*12)>(@tope_fondo_UMA*12) THEN (@tope_fondo_UMA-@tope_fondo)*12 
											ELSE (@emfondoahorrop*@emsalariobase*12)-(@tope_fondo*12) END
				SET @ValorCS = @ExcedentesFinales
				IF (@ExcedentesFinales>0)
				BEGIN
				INSERT INTO [bf_Compensacion_STEmpleado]([CSIdEmpleado],[CSIdCompensacion],[CSMontoCompensacion],[CSIdEstatus],[CSUsuarioAdd],[CSFechaAdd],[CSUsuarioUmod],[CSFechaUmod])
			    VALUES (@idempleado,358,ISNULL(@ExcedentesFinales,0), 1,@idUsuario, getdate(), @idUsuario, getdate())	
				END
				END
			
			
				SET @Excedenteant =ISNULL((SELECT CETotalCreditos FROM dbo.ff_compensacionempleado  WITH (NOLOCK,READUNCOMMITTED) WHERE  ceidempleado = @idempleado and CEidCompensacion = @ccidcompensacion ),-1)		
					IF (@Excedenteant > 0)
                	BEGIN 
                		set @ValorCS = ISNULL(@ValorCS,0)
				       UPDATE  dbo.ff_compensacionempleado SET  cetotalcreditos=@ExcedentesFinales, CEUsuarioUMod = @idUsuario, CEFechaUMod = getdate(), CEidEstatus = 1
						WHERE ceidempleado = @idempleado AND CEidCompensacion = @ccidcompensacion
						INSERT dbo.ff_compensacionempleadohist (ceidcompensacion, ceidempleado, cetotalcreditos, CEidEstatus, CEUsuarioAdd, CEFechaAdd, CEUsuarioUMod, CEFechaUMod)
			         	VALUES (@ccidcompensacion,@idempleado,@Excedenteant, 1,@idUsuario, getdate(), @idUsuario, getdate())
        			END
					ELSE
					BEGIN
						SET @maxCom = (SELECT MAX (ceidcompensacionempleado) + 1 FROM dbo.ff_compensacionempleado  WITH (NOLOCK,READUNCOMMITTED))
						IF (@ExcedentesFinales>0)
						BEGIN
							INSERT dbo.ff_compensacionempleado (ceidcompensacionempleado, ceidcompensacion, ceidempleado, cetotalcreditos, CEidEstatus, CEUsuarioAdd, CEFechaAdd, CEUsuarioUMod, CEFechaUMod)
                       			VALUES (@maxCom,@ccidcompensacion,@idempleado,@ExcedentesFinales, 1,@idUsuario, getdate(), @idUsuario, getdate())	   	               
							INSERT dbo.ff_compensacionempleadohist ( ceidcompensacion, ceidempleado, cetotalcreditos, CEidEstatus, CEUsuarioAdd, CEFechaAdd, CEUsuarioUMod, CEFechaUMod)
			   					VALUES (@ccidcompensacion,@idempleado,@Excedenteant, 1,@idUsuario, getdate(), @idUsuario, getdate())
					END
					END
					SET @contador2 = @contador2+1
				END
				--Termina Mod DB

				Declare @Validador int
				Set @Validador=1
				WHILE (@Validador < 3 )
				BEGIN
				IF (@Validador=1)
				BEGIN
				SET @ccidcompensacion = 170
				set @ExcedentesFinales=645
				SET @Excedenteant =ISNULL((SELECT CETotalCreditos FROM dbo.ff_compensacionempleado  WITH (NOLOCK,READUNCOMMITTED) WHERE  ceidempleado = @idempleado and CEidCompensacion = @ccidcompensacion ),-1)		
					IF (@Excedenteant > 0)
                	BEGIN 
                		UPDATE  dbo.ff_compensacionempleado SET  cetotalcreditos=@ExcedentesFinales, CEUsuarioUMod = @idUsuario, CEFechaUMod = getdate(), CEidEstatus = 1
						WHERE ceidempleado = @idempleado AND CEidCompensacion = @ccidcompensacion
						INSERT INTO [bf_Compensacion_STEmpleado]([CSIdEmpleado],[CSIdCompensacion],[CSMontoCompensacion],[CSIdEstatus],[CSUsuarioAdd],[CSFechaAdd],[CSUsuarioUmod],[CSFechaUmod])
							VALUES (@idempleado,@ccidcompensacion,ISNULL(@ExcedentesFinales,0), 1,@idUsuario, getdate(), @idUsuario, getdate())	
						INSERT dbo.ff_compensacionempleadohist (ceidcompensacion, ceidempleado, cetotalcreditos, CEidEstatus, CEUsuarioAdd, CEFechaAdd, CEUsuarioUMod, CEFechaUMod)
			         	VALUES (@ccidcompensacion,@idempleado,@Excedenteant, 1,@idUsuario, getdate(), @idUsuario, getdate())
        			END
					ELSE
					BEGIN
						SET @maxCom = (SELECT MAX (ceidcompensacionempleado) + 1 FROM dbo.ff_compensacionempleado  WITH (NOLOCK,READUNCOMMITTED))
						IF (@ExcedentesFinales>0)
						BEGIN
							INSERT dbo.ff_compensacionempleado (ceidcompensacionempleado, ceidcompensacion, ceidempleado, cetotalcreditos, CEidEstatus, CEUsuarioAdd, CEFechaAdd, CEUsuarioUMod, CEFechaUMod)
                       			VALUES (@maxCom,@ccidcompensacion,@idempleado,@ExcedentesFinales, 1,@idUsuario, getdate(), @idUsuario, getdate())	 
							INSERT INTO [bf_Compensacion_STEmpleado]([CSIdEmpleado],[CSIdCompensacion],[CSMontoCompensacion],[CSIdEstatus],[CSUsuarioAdd],[CSFechaAdd],[CSUsuarioUmod],[CSFechaUmod])
								VALUES (@idempleado,@ccidcompensacion,ISNULL(@ExcedentesFinales,0), 1,@idUsuario, getdate(), @idUsuario, getdate())	  	               
							INSERT dbo.ff_compensacionempleadohist ( ceidcompensacion, ceidempleado, cetotalcreditos, CEidEstatus, CEUsuarioAdd, CEFechaAdd, CEUsuarioUMod, CEFechaUMod)
			   					VALUES (@ccidcompensacion,@idempleado,@Excedenteant, 1,@idUsuario, getdate(), @idUsuario, getdate())
					END
					END
				END
				ELSE
				BEGIN
				SET @ccidcompensacion = 466
				set @ExcedentesFinales=1200
				SET @Excedenteant =ISNULL((SELECT CETotalCreditos FROM dbo.ff_compensacionempleado  WITH (NOLOCK,READUNCOMMITTED) WHERE  ceidempleado = @idempleado and CEidCompensacion = @ccidcompensacion ),-1)		
					IF (@Excedenteant > 0)
                	BEGIN 
                		UPDATE  dbo.ff_compensacionempleado SET  cetotalcreditos=@ExcedentesFinales, CEUsuarioUMod = @idUsuario, CEFechaUMod = getdate(), CEidEstatus = 1
						WHERE ceidempleado = @idempleado AND CEidCompensacion = @ccidcompensacion
						INSERT INTO [bf_Compensacion_STEmpleado]([CSIdEmpleado],[CSIdCompensacion],[CSMontoCompensacion],[CSIdEstatus],[CSUsuarioAdd],[CSFechaAdd],[CSUsuarioUmod],[CSFechaUmod])
							VALUES (@idempleado,@ccidcompensacion,ISNULL(@ExcedentesFinales,0), 1,@idUsuario, getdate(), @idUsuario, getdate())	
						INSERT dbo.ff_compensacionempleadohist (ceidcompensacion, ceidempleado, cetotalcreditos, CEidEstatus, CEUsuarioAdd, CEFechaAdd, CEUsuarioUMod, CEFechaUMod)
			         	VALUES (@ccidcompensacion,@idempleado,@Excedenteant, 1,@idUsuario, getdate(), @idUsuario, getdate())
        			END
					ELSE
					BEGIN
						SET @maxCom = (SELECT MAX (ceidcompensacionempleado) + 1 FROM dbo.ff_compensacionempleado  WITH (NOLOCK,READUNCOMMITTED))
						IF (@ExcedentesFinales>0)
						BEGIN
							INSERT dbo.ff_compensacionempleado (ceidcompensacionempleado, ceidcompensacion, ceidempleado, cetotalcreditos, CEidEstatus, CEUsuarioAdd, CEFechaAdd, CEUsuarioUMod, CEFechaUMod)
                       			VALUES (@maxCom,@ccidcompensacion,@idempleado,@ExcedentesFinales, 1,@idUsuario, getdate(), @idUsuario, getdate())	   	
							INSERT INTO [bf_Compensacion_STEmpleado]([CSIdEmpleado],[CSIdCompensacion],[CSMontoCompensacion],[CSIdEstatus],[CSUsuarioAdd],[CSFechaAdd],[CSUsuarioUmod],[CSFechaUmod])
								VALUES (@idempleado,@ccidcompensacion,ISNULL(@ExcedentesFinales,0), 1,@idUsuario, getdate(), @idUsuario, getdate())	               
							INSERT dbo.ff_compensacionempleadohist ( ceidcompensacion, ceidempleado, cetotalcreditos, CEidEstatus, CEUsuarioAdd, CEFechaAdd, CEUsuarioUMod, CEFechaUMod)
			   					VALUES (@ccidcompensacion,@idempleado,@Excedenteant, 1,@idUsuario, getdate(), @idUsuario, getdate())
					END
					END
				END
				SET @Validador=@Validador+1
				END
				END
				
				ELSE IF  @idEmpresa <>369 AND @ccidcompensacionDifTipo =0
				BEGIN
				SET  @tope_vales = (@emvalesp*10)* @SalarioMinino
				SET  @tope_fondo = (@emfondoahorrop*10)* @SalarioMinino
				
--						select  @tope_vales = isnull(FCValor,0)  from dbo.ff_FormulaConstante  WITH (NOLOCK,READUNCOMMITTED)  where fcidConstante = 2 and FCidCorporativo = @idCorporativo
--FIN MOD SE MODIFICA PARA QUE OBTENGA LOS TOPES DINAMICOS select  @tope_fondo = isnull(FCValor,0)  from dbo.ff_FormulaConstante  WITH (NOLOCK,READUNCOMMITTED)  where fcidConstante = 3 and FCidCorporativo = @idCorporativo
						SET @CalcVales = (@emvalesp * @emsalariobase) - @tope_vales
						SET @CalcFA = (@emfondoahorrop * @emsalariobase)  - @tope_fondo	
							
						SET @ExcedentesFinales = (@CalcVales + @CalcFA) * 12
						SET @Excedenteant =ISNULL((SELECT CETotalCreditos FROM dbo.ff_compensacionempleado  WITH (NOLOCK,READUNCOMMITTED) WHERE  ceidempleado = @idempleado),0)		
						--SELECT 	@ExcedentesFinales,	@CalcVales,@CalcFA
						--select  @tope_vales,  @tope_fondo,  @CalcVales,  @CalcFA,  @ExcedentesFinales,  @Excedenteant
						
						--print 'PP1'
						--print @tope_vales 
						--print @tope_fondo
						--print @ExcedentesFinales

  						IF @ExcedentesFinales > 0
						BEGIN
							
                			IF (@Excedenteant > 0)
                   			BEGIN 
									--SELECT 'SE ACTUALIZA EL REGISTRO'
									--CAMBIO ES ESTATUS DEL REGISTRO ANTERIOR
									--select  @tope_vales AS tope_vales , @tope_fondo AS tope_FONDO, @CalcVales AS CalcVales, @CalcFA AS CalcFA, @ExcedentesFinales AS ExcedentesFinales
								       UPDATE  dbo.ff_compensacionempleado SET  cetotalcreditos=@ExcedentesFinales, CEUsuarioUMod = @idUsuario, CEFechaUMod = getdate(), CEidEstatus = 1
										WHERE ceidempleado = @idempleado 		
										INSERT dbo.ff_compensacionempleadohist (ceidcompensacion, ceidempleado, cetotalcreditos, CEidEstatus, CEUsuarioAdd, CEFechaAdd, CEUsuarioUMod, CEFechaUMod)
			   			         		VALUES (@ccidcompensacion,@idempleado,@Excedenteant, 1,@idUsuario, getdate(), @idUsuario, getdate())
                    			END
                  			ELSE 
                   				BEGIN 
									--SELECT 'SE INSERTA EL REGISTRO'
									IF EXISTS (SELECT ceidcompensacionempleado FROM dbo.ff_compensacionempleado  WITH (NOLOCK,READUNCOMMITTED) WHERE ceidempleado = @idempleado) AND @ccidcompensacionDifTipo = 0
									BEGIN
											--SELECT 'HAGO UPDATE!!!'
									   UPDATE  dbo.ff_compensacionempleado SET  cetotalcreditos=@ExcedentesFinales, CEUsuarioUMod = @idUsuario, CEFechaUMod = getdate(), CEidEstatus = 1
										WHERE ceidempleado = @idempleado 		
										INSERT dbo.ff_compensacionempleadohist (ceidcompensacion, ceidempleado, cetotalcreditos, CEidEstatus, CEUsuarioAdd, CEFechaAdd, CEUsuarioUMod, CEFechaUMod)
			   			         		VALUES (@ccidcompensacion,@idempleado,@Excedenteant, 1,@idUsuario, getdate(), @idUsuario, getdate())
									END
									ELSE
									BEGIN
											--SELECT 'HAGO INSERT!!!'
									--select  @tope_vales AS tope_vales , @tope_fondo AS tope_FONDO, @CalcVales AS CalcVales, @CalcFA AS CalcFA, @ExcedentesFinales AS ExcedentesFinales
									SET @maxCom = (SELECT MAX (ceidcompensacionempleado) + 1 FROM dbo.ff_compensacionempleado  WITH (NOLOCK,READUNCOMMITTED))
									INSERT dbo.ff_compensacionempleado (ceidcompensacionempleado, ceidcompensacion, ceidempleado, cetotalcreditos, CEidEstatus, CEUsuarioAdd, CEFechaAdd, CEUsuarioUMod, CEFechaUMod)
                       			VALUES (@maxCom,@ccidcompensacion,@idempleado,@ExcedentesFinales, 1,@idUsuario, getdate(), @idUsuario, getdate())	   	               
									INSERT dbo.ff_compensacionempleadohist ( ceidcompensacion, ceidempleado, cetotalcreditos, CEidEstatus, CEUsuarioAdd, CEFechaAdd, CEUsuarioUMod, CEFechaUMod)
			   			          VALUES (@ccidcompensacion,@idempleado,@Excedenteant, 1,@idUsuario, getdate(), @idUsuario, getdate())
									
									END
								END
						END
						ELSE
						BEGIN
                			IF (@Excedenteant > 0)
                   			BEGIN 
									--SELECT 'SE actualiza EL REGISTRO con EXC = 0'
									--select  @tope_vales AS tope_vales , @tope_fondo AS tope_FONDO, @CalcVales AS CalcVales, @CalcFA AS CalcFA, @ExcedentesFinales AS ExcedentesFinales
									UPDATE  dbo.ff_compensacionempleado SET  cetotalcreditos=0, CEUsuarioUMod = @idUsuario, CEFechaUMod = getdate(), CEidEstatus = 1  -- cetotalcreditos = @ExcedentesFinales, 
									WHERE ceidempleado = @idempleado									
									INSERT dbo.ff_compensacionempleadohist ( ceidcompensacion, ceidempleado, cetotalcreditos, CEidEstatus, CEUsuarioAdd, CEFechaAdd, CEUsuarioUMod, CEFechaUMod)
			   			          VALUES (@ccidcompensacion,@idempleado,@Excedenteant, 1,@idUsuario, getdate(), @idUsuario, getdate())                     		
							END
						END
					END
				ELSE IF @ccidcompensacionDifTipo>0 AND @ccidcompensacionDifTipo IS NOT NULL AND @ExcedentesFinales>0
				BEGIN
					IF NOT EXISTS (SELECT ceidcompensacionempleado FROM dbo.ff_compensacionempleado  WITH (NOLOCK,READUNCOMMITTED) WHERE ceidempleado = @idempleado and CeIdCompensacion=@ccidcompensacionDifTipo)
						BEGIN
							SET @maxCom = (SELECT MAX (ceidcompensacionempleado) + 1 FROM dbo.ff_compensacionempleado  WITH (NOLOCK,READUNCOMMITTED))
							INSERT dbo.ff_compensacionempleado (ceidcompensacionempleado, ceidcompensacion, ceidempleado, cetotalcreditos, CEidEstatus, CEUsuarioAdd, CEFechaAdd, CEUsuarioUMod, CEFechaUMod)
                       			VALUES (@maxCom,@ccidcompensacionDifTipo,@idempleado,@ExcedentesFinales, 1,@idUsuario, getdate(), @idUsuario, getdate())	   	               
						END
				
				END					
			END
		end

END 








GO

PRINT 'OK: dbo.ff_VerificaExcedentes restaurado';
GO